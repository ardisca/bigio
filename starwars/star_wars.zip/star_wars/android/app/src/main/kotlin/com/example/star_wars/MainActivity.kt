package com.example.star_wars

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

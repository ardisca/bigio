import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:star_wars/controller/species_controlle.dart';
import 'package:star_wars/ui/page/main_page.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  SpeciesController speciesController = Get.put(SpeciesController());
  @override
  void initState() {
    super.initState();
    _pindahHalaman();
  }

  void _pindahHalaman() async {
    await Future.delayed(const Duration(seconds: 5));
    Get.off(() => const MainPage(), arguments: 1);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Padding(
      padding: const EdgeInsets.all(10),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const SizedBox(
            height: 0,
          ),
          Center(
            child: Lottie.asset('assets/animation/animation_splash.json',
                height: 200),
          ),
          const Text(
            'made with love for Bigio',
            style: TextStyle(color: Colors.grey),
          )
        ],
      ),
    ));
  }
}

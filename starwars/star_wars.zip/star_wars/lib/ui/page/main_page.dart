import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:star_wars/controller/species_controlle.dart';
import 'package:star_wars/ui/page/species/species_page.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  SpeciesController speciesController = Get.find();
  bool isLoading = true;
  int id = Get.arguments;
  List img = [
    Image.asset('assets/spesies/human.png', height: 150),
    Image.asset('assets/spesies/droid.png', height: 150),
    Image.asset('assets/spesies/wookie.png', height: 150),
    Image.asset('assets/spesies/rodian.png', height: 150),
    Image.asset('assets/spesies/huft.png', height: 150),
    Image.asset('assets/spesies/yoda.png', height: 150),
    Image.asset('assets/spesies/trandoshian.png', height: 150),
    Image.asset('assets/spesies/moncalamari.png', height: 150),
    Image.asset('assets/spesies/ewok.png', height: 150),
    Image.asset('assets/spesies/sullustan.png', height: 150),
    Image.asset('assets/spesies/lock.png', height: 150),
  ];
  @override
  void initState() {
    super.initState();
    data(id);
    // print(id);
  }

  void data(int id) async {
    try {
      bool cek = await speciesController.listSpecies(id);
      if (cek == true) {
        setState(() {
          isLoading = false;
        });
      }
    } catch (e) {
      // print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    final panjang = speciesController.responseBodyList.value?.length;

    return Scaffold(
      body: SafeArea(
          child: Container(
              color: Colors.white,
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SvgPicture.asset('assets/logo/logo.svg', height: 70),
                  const SizedBox(
                    width: 25,
                  ),
                  isLoading
                      ? Lottie.asset('assets/animation/animation_loading.json',
                          height: 200)
                      : Expanded(
                          child: GridView.builder(
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 2),
                              itemCount: panjang,
                              itemBuilder: (context, index) {
                                String nama = speciesController
                                    .responseBodyList.value?[index]['name'];
                                return GridTile(
                                  child: InkWell(
                                    onTap: () {
                                      int idPeople = index + 1;
                                      Get.to(() => const SpeciesPage(),
                                          arguments: {
                                            'idPeople': idPeople,
                                            'page': id
                                          });
                                      // print('idPeople $idPeople');
                                      // print('page $id');
                                    },
                                    child: Container(
                                      margin: const EdgeInsets.all(10),
                                      // padding: const EdgeInsets.all(10),
                                      decoration: const BoxDecoration(
                                          color: Colors.amber,
                                          boxShadow: [
                                            BoxShadow(
                                              color: Color.fromRGBO(
                                                  74, 85, 104, 0.2),
                                              spreadRadius: 2,
                                              blurRadius: 10,
                                              offset: Offset(0, 6),
                                            ),
                                          ],
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(20))),
                                      child: ClipRRect(
                                        borderRadius: const BorderRadius.all(
                                            Radius.circular(20)),
                                        child: Stack(
                                          alignment: Alignment.bottomCenter,
                                          children: [
                                            // Image.asset(
                                            //     'assets/spesies/lock.png',
                                            //     height: 150),
                                            if (id == 1) img[index],
                                            if (id != 1) img[10],
                                            Container(
                                              height: double.infinity,
                                              width: double.infinity,
                                              decoration: const BoxDecoration(
                                                gradient: LinearGradient(
                                                  begin: Alignment.topCenter,
                                                  end: Alignment.bottomCenter,
                                                  colors: [
                                                    Colors
                                                        .transparent, // Warna transparan di atas
                                                    Colors
                                                        .amber, // Warna kuning di bawah
                                                  ],
                                                  stops: [
                                                    0.0,
                                                    1.0
                                                  ], // Pengaturan nilai berhenti (0.0 untuk transparan, 1.0 untuk kuning)
                                                ),
                                              ),
                                            ),
                                            Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.end,
                                              children: [
                                                Text(
                                                  nama,
                                                  style: const TextStyle(
                                                      fontSize: 17.5,
                                                      color: Colors.white,
                                                      fontWeight:
                                                          FontWeight.w700),
                                                ),
                                                Text(
                                                  '${speciesController.responseBodyList.value?[index]['classification']}',
                                                  style: const TextStyle(
                                                      color: Colors.white,
                                                      fontWeight:
                                                          FontWeight.w500),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              }),
                        ),
                  isLoading
                      ? const CircularProgressIndicator()
                      : Container(
                          padding: const EdgeInsets.only(top: 20),
                          // color: Colors.amber,
                          alignment: Alignment.center,
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                if (speciesController.responseBodyPrevious !=
                                    '')
                                  InkWell(
                                    onTap: () {
                                      setState(() {
                                        id--;
                                        data(id);
                                        isLoading = true;
                                        // print(id);
                                      });
                                    },
                                    child: Container(
                                      decoration: const BoxDecoration(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(15)),
                                          color: Colors.amber),
                                      padding: const EdgeInsets.all(10),
                                      child: const Text('Previous'),
                                    ),
                                  ),
                                // else
                                // SizedBox.shrink()
                                const SizedBox(
                                  width: 10,
                                ),
                                if (speciesController.responseBodyNext != '')
                                  InkWell(
                                    onTap: () {
                                      setState(() {
                                        id++;
                                        data(id);
                                        isLoading = true;
                                      });
                                    },
                                    child: Container(
                                      decoration: const BoxDecoration(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(15)),
                                          color: Colors.amber),
                                      padding: const EdgeInsets.all(10),
                                      child: const Text('Next'),
                                    ),
                                  )
                              ]),
                        )
                ],
              ))),
    );
  }
}

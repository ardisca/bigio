import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:star_wars/controller/homeworld_controller.dart';
import 'package:star_wars/controller/people_controller.dart';
import 'package:star_wars/controller/species_controlle.dart';

class SpeciesPage extends StatefulWidget {
  const SpeciesPage({super.key});

  @override
  State<SpeciesPage> createState() => _SpeciesPageState();
}

class _SpeciesPageState extends State<SpeciesPage> {
  SpeciesController speciesController = Get.find();
  HomewoldController homewoldController = Get.put(HomewoldController());
  PeopleController peopleController = Get.put(PeopleController());
  List peopleData = [];
  List peopleDataName = [];
  bool isLoading = true;
  final arguments = Get.arguments;

  // final id = Get.arguments as int;

  List img = [
    Image.asset(
      'assets/spesies/human.png',
    ),
    Image.asset(
      'assets/spesies/droid.png',
      height: 150,
    ),
    Image.asset('assets/spesies/wookie.png', height: 150),
    Image.asset('assets/spesies/rodian.png', height: 150),
    Image.asset('assets/spesies/huft.png', height: 150),
    Image.asset('assets/spesies/yoda.png', height: 150),
    Image.asset('assets/spesies/trandoshian.png', height: 150),
    Image.asset('assets/spesies/moncalamari.png', height: 150),
    Image.asset('assets/spesies/ewok.png', height: 150),
    Image.asset('assets/spesies/sullustan.png', height: 150),
    Image.asset('assets/spesies/lock.png', height: 150),
  ];
  @override
  void initState() {
    super.initState();
    data();
    // print(id);
  }

  @override
  void dispose() {
    super.dispose();
  }

  void data() async {
    final page = arguments['page'];
    int kalkulate = {1: 0, 2: 10, 3: 20, 4: 30}[page] ?? 0;

    final id = arguments['idPeople'] + kalkulate;

    // print('idkep $id');
    try {
      bool test = await speciesController.getdetailSpecies(id);
      if (test == true) {
        if (speciesController.responseBodyDetails.value?['homeworld'] != null) {
          dataWorld();
        } else {
          setState(() {
            isLoading = false;
          });
        }
      }
    } catch (e) {
      // print(e);
    }
  }

  void dataWorld() async {
    final idworld = speciesController.responseBodyDetails.value?['homeworld']
        .replaceAll("https://swapi.dev/api/planets/", "")
        .replaceAll("/", "");
    try {
      bool test = await homewoldController.getworld(idworld);
      if (test == true) {
        setState(() {
          isLoading = false;
        });
        // print(homewoldController.responseBodyDetails.value);
      }
    } catch (e) {
      // print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    final nama = speciesController.responseBodyDetails.value?['name'];
    final classification =
        speciesController.responseBodyDetails.value?['classification'];
    final designation =
        speciesController.responseBodyDetails.value?['designation'];
    final averageHeight =
        speciesController.responseBodyDetails.value?['average_height'];
    final language = speciesController.responseBodyDetails.value?['language'];
    final homeworld = speciesController.responseBodyDetails.value?['homeworld'];
    final people = speciesController.responseBodyDetails.value?['people'];

    final page = arguments['page'];
    final idPeople = arguments['idPeople'];
    return Scaffold(
      body: SafeArea(
          child: SingleChildScrollView(
        child: isLoading
            ? Center(
                child: LottieBuilder.asset(
                    'assets/animation/animation_loading_sword.json'))
            : Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      // color: Colors.amber,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          InkWell(
                            onTap: () {
                              Get.back();
                            },
                            child: Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                    border: Border.all(
                                      color: const Color(0xffE3E9ED),
                                    ),
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(100 / 2))),
                                child:
                                    const Icon(Icons.arrow_back_ios_outlined)),
                          ),
                          const Text('Detail',
                              style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w700,
                                  color: Color(0xff1F2C37))),
                          InkWell(
                              onTap: () {},
                              child: Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                    border: Border.all(
                                      color: const Color(0xffE3E9ED),
                                    ),
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(100 / 2))),
                                child: Image.asset('assets/logo/logos2.png',
                                    height: 25),
                              )),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Container(
                        height: 300,
                        width: double.infinity,
                        decoration: const BoxDecoration(
                            color: Colors.amber,
                            boxShadow: [
                              BoxShadow(
                                color: Color.fromRGBO(74, 85, 104, 0.2),
                                spreadRadius: 2,
                                blurRadius: 10,
                                offset: Offset(0, 6),
                              ),
                            ],
                            borderRadius:
                                BorderRadius.all(Radius.circular(20))),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child: Stack(
                            alignment: page == 1
                                ? Alignment.center
                                : Alignment.bottomCenter,
                            children: [
                              Transform.scale(
                                scale: 2,
                                child: page == 1 ? img[idPeople - 1] : img[10],
                              ),
                              Container(
                                height: double.infinity,
                                width: double.infinity,
                                decoration: const BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      Colors
                                          .transparent, // Warna transparan di atas
                                      Colors.amber, // Warna kuning di bawah
                                    ],
                                    stops: [
                                      0.0,
                                      1.0
                                    ], // Pengaturan nilai berhenti (0.0 untuk transparan, 1.0 untuk kuning)
                                  ),
                                ),
                              ),
                              Container(
                                height: double.infinity,
                                width: double.infinity,
                                alignment: Alignment.bottomCenter,
                                child: Text(
                                  '$nama',
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 30,
                                      fontWeight: FontWeight.w900),
                                ),
                              ),
                            ],
                          ),
                        )),
                    Container(
                      margin: const EdgeInsets.symmetric(vertical: 20),
                      width: double.infinity,
                      alignment: Alignment.center,
                      child: Column(
                        children: [
                          RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              text: 'Classification\n',
                              style: const TextStyle(
                                  color: Colors.black, fontSize: 20),
                              children: [
                                TextSpan(
                                  text: classification,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              text: 'Designation\n',
                              style: const TextStyle(
                                  color: Colors.black, fontSize: 20),
                              children: [
                                TextSpan(
                                  text: designation,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              text: 'Average Height\n',
                              style: const TextStyle(
                                  color: Colors.black, fontSize: 20),
                              children: [
                                TextSpan(
                                  text: averageHeight,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              text: 'Language\n',
                              style: const TextStyle(
                                  color: Colors.black, fontSize: 20),
                              children: [
                                TextSpan(
                                  text: language,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              text: 'Homeworld\n',
                              style: const TextStyle(
                                  color: Colors.black, fontSize: 20),
                              children: [
                                TextSpan(
                                  text:
                                      '${homeworld == null ? 'n/a' : homewoldController.responseBodyDetails.value?['name']}',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                        ],
                      ),
                    ),
                    const Text(
                      'People',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 20,
                      ),
                    ),
                    SizedBox(
                      height: 200,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) {
                          peopleData.add(people[index]
                              .replaceAll("https://swapi.dev/api/people/", "")
                              .replaceAll("/", ""));
                          // print(peopleData[index]);
                          return FutureBuilder<String>(
                            future:
                                peopleController.getpeople(peopleData[index]),
                            builder: (context, snapshot) {
                              // print(peopleData[index]);
                              if (snapshot.connectionState ==
                                  ConnectionState.waiting) {
                                return LottieBuilder.asset(
                                    'assets/animation/animation_loading_sword.json');
                              } else if (snapshot.hasError) {
                                return Text('Error: ${snapshot.error}');
                              } else {
                                return Container(
                                  decoration: BoxDecoration(
                                      boxShadow: const [
                                        BoxShadow(
                                          color:
                                              Color.fromRGBO(74, 85, 104, 0.2),
                                          spreadRadius: 2,
                                          blurRadius: 10,
                                          offset: Offset(0, 6),
                                        ),
                                      ],
                                      color: Colors.amber,
                                      borderRadius: BorderRadius.circular(15)),
                                  margin: const EdgeInsets.all(10),
                                  // padding: const EdgeInsets.all(10),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(15),
                                    child: Stack(
                                      alignment: Alignment.bottomCenter,
                                      children: [
                                        img[10],
                                        Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Text(
                                            peopleController.responseBodyList
                                                    .value?['name'] ??
                                                '',
                                            style: const TextStyle(
                                                color: Colors.white,
                                                fontSize: 15),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              }
                            },
                          );
                        },
                        itemCount: people.length,
                      ),
                    )
                  ],
                ),
              ),
      )),
    );
  }
}

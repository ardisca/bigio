import 'dart:convert';

import 'package:get/get.dart';

import 'package:http/http.dart' as http;

class PeopleController extends GetxController {
  Rx<Map?> responseBodyList = Rx<Map?>(null);

  Future<String> getpeople(String id) async {
    try {
      final response = await http
          .get(Uri.parse('https://swapi.dev/api/people/$id/?format=json'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        responseBodyList.value = data;
        return '${responseBodyList.value?['name']}';
      } else {
        throw Exception('Failed to load data');
      }
    } catch (e) {
      // print('Error: $e');
      return 'false';
    }
  }
}

import 'dart:convert';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import 'package:http/http.dart' as http;

class HomewoldController extends GetxController {
  final box = GetStorage();
  Rx<Map?> responseBodyDetails = Rx<Map?>(null);
  Future getworld(String id) async {
    final cachedData = box.read('getworld_$id');
    if (cachedData != null) {
      final data = cachedData;
      responseBodyDetails.value = data;
      return true;
    } else {
      try {
        final response = await http
            .get(Uri.parse('https://swapi.dev/api/planets/$id/?format=json'));
        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          responseBodyDetails.value = data;
          // Menyimpan data ke cache.
          box.write('getworld_$id', data);
          return true;
        } else {
          throw Exception('Failed to load data');
        }
      } catch (e) {
        return false;
      }
    }
  }
}

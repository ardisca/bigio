import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class SpeciesController extends GetxController {
  final box = GetStorage();
  Rx<List?> responseBodyList = Rx<List?>(null);
  String responseBodyNext = '';
  String responseBodyPrevious = '';
  Rx<Map?> responseBodyDetails = Rx<Map?>(null);

  Future getdetailSpecies(int id) async {
    final cachedData = box.read('speciesdetail_$id');
    if (cachedData != null) {
      final data = cachedData;
      responseBodyDetails.value = data;
      return true;
    } else {
      try {
        final response = await http
            .get(Uri.parse('https://swapi.dev/api/species/$id?format=json'));
        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          responseBodyDetails.value = data;
          // Menyimpan data ke cache.
          box.write('speciesdetail_$id', data);
          return true;
        } else {
          throw Exception('Failed to load data');
        }
      } catch (e) {
        // print('Error: $e');
        return false;
      }
    }
  }

  Future<bool> listSpecies(int page) async {
    final cachedData = box.read('species_$page');
    if (cachedData != null) {
      final data = cachedData;
      responseBodyList.value = data['results'];
      responseBodyNext = data['next'] ?? '';
      responseBodyPrevious = data['previous'] ?? '';
      return true;
    } else {
      try {
        final response = await http
            .get(Uri.parse('https://swapi.dev/api/species/?page=$page'));

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          responseBodyList.value = data['results'];
          responseBodyNext = data['next'] ?? '';
          responseBodyPrevious = data['previous'] ?? '';

          // Menyimpan data ke cache.
          box.write('species_$page', data);
          return true;
        } else {
          throw Exception('Failed to load data');
        }
      } catch (e) {
        // print('Error: $e');
        return false;
      }
    }
  }
}
